$(document)
    .on('click.bs.dropdown.data-api', '.dropdown', function (e) { e.stopPropagation() })
